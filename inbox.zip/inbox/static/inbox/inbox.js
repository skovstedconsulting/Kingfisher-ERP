(function () {
  const bc = new BroadcastChannel("kf_inbox_preview");

  function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return "";
  }
  const csrftoken = getCookie("csrftoken");

  function broadcast(url, title) {
    bc.postMessage({ type: "show_attachment", url, title });
  }

  function openPopout(attachmentId) {
    if (!attachmentId) return;
    const url = `/inbox/attachment/${attachmentId}/popout/`;
    window.open(url, "kf_inbox_popout", "popup=yes,width=1100,height=900,noopener,noreferrer");
  }

  function setPreviewToUrl(url, isPdf) {
    const wrap = document.getElementById("kf-preview-wrap");
    if (!wrap) return;

    wrap.innerHTML = "";

    if (isPdf) {
      const iframe = document.createElement("iframe");
      iframe.src = url;
      iframe.style.width = "100%";
      iframe.style.height = "calc(100vh - 220px)";
      iframe.style.border = "1px solid #ddd";
      iframe.style.borderRadius = "10px";
      iframe.style.background = "#fff";
      wrap.appendChild(iframe);
    } else {
      const img = document.createElement("img");
      img.src = url;
      img.style.maxWidth = "100%";
      img.style.height = "auto";
      img.style.border = "1px solid #ddd";
      img.style.borderRadius = "10px";
      img.style.background = "#fff";
      wrap.appendChild(img);
    }
  }


  // Select row
  document.querySelectorAll(".kf-inbox-row").forEach((row) => {
    row.addEventListener("click", () => {
      const docId = row.getAttribute("data-doc-id");
      const u = new URL(window.location.href);
      u.searchParams.set("selected", docId);
      window.location.href = u.toString();
    });
  });

  // Toggle preview
  const toggleBtn = document.getElementById("kf-toggle-preview");
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      const wrap = document.getElementById("kf-preview-wrap");
      if (!wrap) return;
      const hidden = wrap.style.display === "none";
      wrap.style.display = hidden ? "" : "none";
      toggleBtn.textContent = hidden ? "Hide preview" : "Show preview";
    });
  }

  // Popout
  const popBtn = document.getElementById("kf-popout-btn");
  if (popBtn) {
    popBtn.addEventListener("click", () => {
      const selectedAtt = document.querySelector(".kf-attachment-btn.kf-selected-attachment");
      const attId = selectedAtt?.getAttribute("data-attachment-id")
        || document.querySelector(".kf-inbox-row[style*='background']")?.getAttribute("data-primary-attachment-id");
      openPopout(attId);
    });
  }

  // Attachment click
  document.querySelectorAll(".kf-attachment-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".kf-attachment-btn")
        .forEach(b => b.classList.remove("kf-selected-attachment"));
      btn.classList.add("kf-selected-attachment");

      const url = btn.getAttribute("data-url");        // raw
      const viewUrl = btn.getAttribute("data-view-url"); // iframe-safe
      const isPdf = (url || "").toLowerCase().endsWith(".pdf");

      const chosen = isPdf ? viewUrl : url;

      if (chosen) {
        setPreviewToUrl(chosen, isPdf);   // <-- see next section
        broadcast(chosen, "Inbox preview");
      }
    });
  });

  // On load: broadcast primary
  const selectedRow = document.querySelector(".kf-inbox-row[style*='background']");
  const selectedId = selectedRow?.getAttribute("data-doc-id");
  if (selectedRow) {
    const url = selectedRow.getAttribute("data-primary-url");
    if (url) broadcast(url, "Inbox preview");
  }

  // Drag-drop helpers
  async function uploadCreate(files) {
    if (!files || !files.length) return;

    // Create document with first file, attach the rest
    const fd = new FormData();
    fd.append("doc_type", "other");
    fd.append("title", "");
    fd.append("file", files[0]);

    const resp = await fetch("/api/inbox/documents/create/", {
      method: "POST",
      headers: { "X-CSRFToken": csrftoken },
      body: fd,
      credentials: "same-origin",
    });
    if (!resp.ok) throw new Error("Create failed");
    const data = await resp.json();
    const docId = data.id;

    for (let i = 1; i < files.length; i++) {
      const fd2 = new FormData();
      fd2.append("file", files[i]);
      fd2.append("is_primary", "false");
      await fetch(`/api/inbox/documents/${docId}/attach/`, {
        method: "POST",
        headers: { "X-CSRFToken": csrftoken },
        body: fd2,
        credentials: "same-origin",
      });
    }

    const u = new URL(window.location.href);
    u.searchParams.set("selected", docId);
    window.location.href = u.toString();
  }

  async function uploadAttach(docId, files) {
    if (!docId || !files || !files.length) return;

    for (let i = 0; i < files.length; i++) {
      const fd = new FormData();
      fd.append("file", files[i]);
      fd.append("is_primary", "false");
      const resp = await fetch(`/api/inbox/documents/${docId}/attach/`, {
        method: "POST",
        headers: { "X-CSRFToken": csrftoken },
        body: fd,
        credentials: "same-origin",
      });
      if (!resp.ok) throw new Error("Attach failed");
    }
    window.location.reload();
  }

  function bindDropZone(el, onFiles) {
    if (!el) return;
    el.addEventListener("dragover", (e) => {
      e.preventDefault();
      el.style.background = "#f5f7ff";
    });
    el.addEventListener("dragleave", () => {
      el.style.background = "";
    });
    el.addEventListener("drop", (e) => {
      e.preventDefault();
      el.style.background = "";
      const files = Array.from(e.dataTransfer.files || []);
      onFiles(files);
    });
  }

  // Create drop zone
  bindDropZone(document.getElementById("kf-drop-create"), (files) => {
    uploadCreate(files).catch(err => alert(err.message || "Upload failed"));
  });
  const createInput = document.getElementById("kf-file-create");
  if (createInput) {
    createInput.addEventListener("change", () => {
      uploadCreate(Array.from(createInput.files || [])).catch(err => alert(err.message || "Upload failed"));
    });
  }

  // Attach drop zone
  bindDropZone(document.getElementById("kf-drop-attach"), (files) => {
    uploadAttach(selectedId, files).catch(err => alert(err.message || "Attach failed"));
  });
  const attachInput = document.getElementById("kf-file-attach");
  if (attachInput) {
    attachInput.addEventListener("change", () => {
      uploadAttach(selectedId, Array.from(attachInput.files || [])).catch(err => alert(err.message || "Attach failed"));
    });
  }

  // Popout ready
  bc.onmessage = (e) => {
    const msg = e.data || {};
    if (msg.type === "popout_ready") {
      const iframe = document.getElementById("kf-main-preview-frame");
      const img = document.getElementById("kf-main-preview-img");
      const url = (iframe && iframe.src) || (img && img.src);
      if (url) broadcast(url, "Inbox preview");
    }
  };
})();
